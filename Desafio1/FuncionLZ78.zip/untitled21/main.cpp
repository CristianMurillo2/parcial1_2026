#include <iostream>
#include <fstream>
using namespace std;
#define MAX_WORD_SIZE 1024

void copiar(char *dest, char *src) {
    int i = 0;
    while (src[i] != '\0') {
        dest[i] = src[i];
        i++;
    }
    dest[i] = '\0';
}
int longitud(char *s) {
    int Longitud = 0;
    while (s[Longitud] != '\0') {
        Longitud++;
    }
    return Longitud;
}

char* concatenarDiccionario(char **diccionario, int indice, char caracter) {
    int longitudCadena = 0;
    if (indice >= 0) longitudCadena = longitud(diccionario[indice]);
    char *nuevaCadena = (char*)malloc(longitudCadena + 2);
    int i;
    for (i = 0; i < longitudCadena; i++) {
        nuevaCadena[i] = diccionario[indice][i];
    }
    nuevaCadena[i++] = caracter;
    nuevaCadena[i] = '\0';
    return nuevaCadena;
}
int buscarDiccionario(char **diccionario, int diccionarioLongitud, char *input, int inicio, int inputLongitud, int *match_len) {
    int max_idx = -1, longitudMaxima = 0;
    for (int i = 0; i < diccionarioLongitud; i++) {
        int longitud1 = longitud(diccionario[i]);
        if (longitud1 == 0) continue;
        if (inicio + longitud1> inputLongitud) continue;
        int encontrado = 1;
        for (int j = 0; j < longitud1; j++) {
            if (diccionario[i][j] != input[inicio + j]) {
                encontrado = 0;
                break;
            }
        }
        if (encontrado && longitud1 > longitudMaxima) {
            longitudMaxima = longitud1;
            max_idx = i;
        }
    }
    *match_len = longitudMaxima;
    return max_idx;
}

void comprimirLZ78(char *entrada, int **salidaPrefijos, char **salidaCaracteres, int *tamSalida) {
    int largoEntrada = longitud(entrada);
    char **diccionario = (char**)malloc(sizeof(char*) * (largoEntrada + 1));
    int tamDiccionario = 0;
    for (int i = 0; i < largoEntrada + 1; i++) {
        diccionario[i] = (char*)malloc(MAX_WORD_SIZE);
        diccionario[i][0] = '\0';
    }
    int *prefijos = (int*)malloc(sizeof(int) * largoEntrada);
    char *caracteres = (char*)malloc(sizeof(char) * largoEntrada);
    int largoCompresion = 0;
    int i = 0;
    while (i < largoEntrada) {
        int tamCoincidencia = 0;
        int indice = buscarDiccionario(diccionario, tamDiccionario, entrada, i, largoEntrada, &tamCoincidencia);
        if (indice == -1) {
            prefijos[largoCompresion] = 0;
            caracteres[largoCompresion] = entrada[i];
            diccionario[tamDiccionario][0] = entrada[i];
            diccionario[tamDiccionario][1] = '\0';
            tamDiccionario++;
            i++;
        } else {
            if (i + tamCoincidencia < largoEntrada) {
                prefijos[largoCompresion] = indice + 1;
                caracteres[largoCompresion] = entrada[i + tamCoincidencia];
                char *nuevaCadena = concatenarDiccionario(diccionario, indice, entrada[i + tamCoincidencia]);
                copiar(diccionario[tamDiccionario], nuevaCadena);
                free(nuevaCadena);
                tamDiccionario++;
                i += tamCoincidencia + 1;
            } else {
                break;
            }
        }
        largoCompresion++;
    }
    *salidaPrefijos = (int*)malloc(sizeof(int) * largoCompresion);
    *salidaCaracteres = (char*)malloc(sizeof(char) * largoCompresion);
    for (int j = 0; j < largoCompresion; j++) {
        (*salidaPrefijos)[j] = prefijos[j];
        (*salidaCaracteres)[j] = caracteres[j];
    }
    *tamSalida = largoCompresion;
    for (int j = 0; j < largoEntrada + 1; j++) free(diccionario[j]);
    free(diccionario);
    free(prefijos);
    free(caracteres);
}
void lz78_descomprimir(unsigned char *comprimido, int tamano) {
    int tam_max=1024;
    char **diccionario = new char*[tamano + 1];
    for (int i = 0; i < tamano + 1; i++) {
        diccionario[i] = new char[tam_max];
        diccionario[i][0] = '\0';
    }

    ofstream f("salida.txt");
    if (!f.is_open()) {
        cout << "No se pudo abrir salida.txt\n";
        return;
    }

    int diccionarioLongitud = 0;
    int i = 0;
    while (i + 1 < tamano) {
        int p = comprimido[i] - '0';
        char c = (char)comprimido[i + 1];
        i += 2;

        if (p == 0) {
            diccionario[diccionarioLongitud][0] = c;
            diccionario[diccionarioLongitud][1] = '\0';
        } else {
            int j = 0;
            while (diccionario[p - 1][j] != '\0') {
                diccionario[diccionarioLongitud][j] = diccionario[p - 1][j];
                j++;
            }
            diccionario[diccionarioLongitud][j] = c;
            diccionario[diccionarioLongitud][j + 1] = '\0';
        }

        // escribir en archivo
        int j = 0;
        while (diccionario[diccionarioLongitud][j] != '\0') {
            f.put(diccionario[diccionarioLongitud][j]);
            j++;
        }

        diccionarioLongitud++;
    }
    f.close();
    for (int k = 0; k < tamano + 1; k++) delete[] diccionario[k];
    delete[] diccionario;
}
int main() {
    unsigned char comprimido[] = {'0','A','0','B','1','A','2','A','3','B'};

    int longitud = sizeof(comprimido);

    lz78_descomprimir(comprimido, longitud);

    cout << "Descompresion terminada. Revisa salida.txt" << endl;
    return 0;
}
